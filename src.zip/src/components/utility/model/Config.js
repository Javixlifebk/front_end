import React, { Component } from "react";

export default class Config  {
 
    constructor(props) {
        super(props);
        this.state = {
            targetUrl:"http://143.244.136.145",
            Port :3001
            }
        }

         /*function getUrl() {
            
            const url=this.state.targetUrl + ":" + this.state.Port;
             
            return url;
        }*/

        


}